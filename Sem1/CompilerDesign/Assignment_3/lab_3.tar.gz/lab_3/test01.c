/*
  Test 1, uninitialized variables.
*/
#include <stdio.h>

int main()
{
    int k; 
    float f;  
  
    printf("%d %f\n", k, f);
    
    return 0;
}
