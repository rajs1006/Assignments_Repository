/* First-Name Last-Name Matr-No */

/* TODO: Add a short explanation of your algorithm here.
 * E.g., if you use iterative data-flow analysis, write down
 * the used gen/kill sets and flow-equations here. */

#define LLVM_VERSION_NUM \
  (LLVM_VERSION_MAJOR * 10000 + LLVM_VERSION_MINOR * 100 + LLVM_VERSION_PATCH)

// Include some headers that might be useful
#include <llvm/Pass.h>
#include <llvm/IR/LLVMContext.h>
#include <llvm/IR/Function.h>
#include <llvm/IR/Instruction.h>
#include <llvm/IR/Instructions.h>
#include <llvm/IR/IntrinsicInst.h>
#if LLVM_VERSION_NUM >= 30700
# include <llvm/IR/DebugInfoMetadata.h>
#else
# include <llvm/IR/DebugInfo.h>
#endif
#include <llvm/IR/CFG.h>
#include <llvm/IR/InstIterator.h>
#include <llvm/IR/Constants.h>
#include <llvm/IR/ValueMap.h>
#include <llvm/ADT/BitVector.h>
#include <llvm/ADT/DenseSet.h>
#include <llvm/Support/raw_ostream.h>

using namespace llvm;

namespace {

class DefinitionPass : public FunctionPass {
public:
  static char ID;
  DefinitionPass() : FunctionPass(ID) {}

  virtual void getAnalysisUsage(AnalysisUsage &au) const {
    au.setPreservesAll();
  }

  virtual bool runOnFunction(Function &F) {
    // Example: Print all stores and where they occur
    for (BasicBlock &BB : F) {
      for (Instruction &I : BB) {
        if (StoreInst *SI = dyn_cast<StoreInst>(&I)) {
          Value *PtrOp = SI->getPointerOperand(); // Store target
          const DebugLoc &Loc = SI->getDebugLoc();
          StringRef Name = getVarName(*PtrOp, F);
          if (!Name.empty() && isValidDebugLoc(Loc)) {
            errs() << "Variable " << Name
                   << " written on line " << Loc.getLine() << "\n";
          }
        }
      }
    }

    // We did not modify the function
    return false;
  }

private:
  /* Extract variable name from debug metadata. */
  StringRef getVarName(const Value &V, const Function &F) {
    for (const BasicBlock &BB : F) {
      for (const Instruction &I : BB) {
        if (const DbgDeclareInst *DbgDeclare = dyn_cast<const DbgDeclareInst>(&I)) {
          if (DbgDeclare->getAddress() == &V) {
#if LLVM_VERSION_NUM >= 30700
            const DILocalVariable *Var = DbgDeclare->getVariable();
            return Var->getName();
#else
            const MDNode *Var = DbgDeclare->getVariable();
            return DIVariable(Var).getName();
#endif
          }
        }
      }
    }
    return "";
  }

  /* Check whether a debug location is valid.
   * A getLine() call on an invalid DebugLoc may crash. */
  bool isValidDebugLoc(const DebugLoc &Loc) {
#if LLVM_VERSION_NUM >= 30700
    return (bool) Loc;
#else
    return !Loc.isUnknown();
#endif
  }
};

class FixingPass : public FunctionPass {
public:
  static char ID;
  FixingPass() : FunctionPass(ID) {}

  virtual void getAnalysisUsage(AnalysisUsage &au) const {
    au.setPreservesCFG();
  }

  virtual bool runOnFunction(Function &F) {
    // TODO

    // The function was modified
    return true;
  }
};

} // namespace


char DefinitionPass::ID = 0;
char FixingPass::ID = 1;

// Pass registrations
static RegisterPass<DefinitionPass> X("def-pass", "Uninitialized variable pass");
static RegisterPass<FixingPass> Y("fix-pass", "Fixing initialization pass");
