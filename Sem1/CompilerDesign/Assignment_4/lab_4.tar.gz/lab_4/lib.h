extern void print_int(int);
extern void print_nl(void);
