#include "lib.h"

// Basic division and multiplication
int main() {
	int a = 42;
	int b = 5;
	print_int(a * b);
	print_nl();
	print_int(a / b);
	print_nl();
	print_int(a % b);
	return 0;
}
