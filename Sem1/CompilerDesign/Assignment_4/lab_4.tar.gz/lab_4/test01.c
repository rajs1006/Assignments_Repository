#include "lib.h"

// This test case should work out of the box
int main() {
	print_int(42);
	return 0;
}
