#include "lib.h"

// Basic add and subtract
int main() {
	int a = 1;
	int b = 2;
	print_int(a + b);
	print_nl();
	print_int(a - b);
	return 0;
}
